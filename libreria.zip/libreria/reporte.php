<?php
include "../Reporte/libreria/fpdf.php";
include 'conexion.php';

if (isset($_GET['id'])) {
    $factura_id = $_GET['id'];

    // Consultar los datos de la factura
    $sql_factura = "SELECT * FROM Facturas WHERE id = ?";
    $stmt_factura = sqlsrv_query($conn, $sql_factura, array($factura_id));
    if ($stmt_factura === false) {
        die(print_r(sqlsrv_errors(), true));
    }
    $factura = sqlsrv_fetch_array($stmt_factura, SQLSRV_FETCH_ASSOC);

    // Consultar los detalles de la factura
    $sql_detalles = "SELECT * FROM DetallesFactura WHERE factura_id = ?";
    $stmt_detalles = sqlsrv_query($conn, $sql_detalles, array($factura_id));
    if ($stmt_detalles === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Crear el PDF
    $pdf = new FPDF($orientation='P', $unit='mm');
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 20);
    $textypos = 5;
    $pdf->setY(12);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "NOMBRE DE LA EMPRESA");

    // Información de la empresa
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->setY(30);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "DE:");
    $pdf->SetFont('Arial', '', 10);
    $pdf->setY(35);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "Nombre de la empresa");
    $pdf->setY(40);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "Direccion de la empresa");
    $pdf->setY(45);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "Telefono de la empresa");
    $pdf->setY(50);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "Email de la empresa");

    // Información del cliente
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->setY(30);
    $pdf->setX(75);
    $pdf->Cell(5, $textypos, "PARA:");
    $pdf->SetFont('Arial', '', 10);
    $pdf->setY(35);
    $pdf->setX(75);
    $pdf->Cell(5, $textypos, $factura['cliente_nombre']);
    $pdf->setY(40);
    $pdf->setX(75);
    $pdf->Cell(5, $textypos, $factura['cliente_direccion']);
    $pdf->setY(45);
    $pdf->setX(75);
    $pdf->Cell(5, $textypos, $factura['cliente_telefono']);
    $pdf->setY(50);
    $pdf->setX(75);
    $pdf->Cell(5, $textypos, $factura['cliente_email']);

    // Información de la factura
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->setY(30);
    $pdf->setX(135);
    $pdf->Cell(5, $textypos, "FACTURA #" . $factura['id']);
    $pdf->SetFont('Arial', '', 10);
    $pdf->setY(35);
    $pdf->setX(135);
    $pdf->Cell(5, $textypos, "Fecha: " . $factura['fecha']->format('d/M/Y'));

    // Tabla de productos
    $pdf->setY(60);
    $pdf->setX(10);
    $pdf->Ln();

    // Cabecera de la tabla
    $header = array("Descripcion", "Cant.", "Precio", "IVA (%)", "Subtotal");
    $w = array(80, 20, 25, 20, 25);
    for ($i = 0; $i < count($header); $i++) {
        $pdf->Cell($w[$i], 7, $header[$i], 1, 0, 'C');
    }
    $pdf->Ln();

    // Datos de los productos
    $total = 0;
    $productos = []; // Inicializar un array para almacenar los productos
    while ($detalle = sqlsrv_fetch_array($stmt_detalles, SQLSRV_FETCH_ASSOC)) {
        $descripcion = $detalle['descripcion'];
        $cantidad = $detalle['cantidad'];
        $precio = $detalle['precio'];
        $iva_tasa = $detalle['iva_tasa'];
        $subtotal = $cantidad * $precio;

        $productos[] = array($descripcion, $cantidad, $precio, $iva_tasa, $subtotal);
        $total += $subtotal;
    }

    // Mostrar productos en el PDF
    foreach ($productos as $producto) {
        $pdf->Cell($w[0], 6, $producto[0], 1);
        $pdf->Cell($w[1], 6, number_format($producto[1]), 1, 0, 'R');
        $pdf->Cell($w[2], 6, "$ " . number_format($producto[2], 2, ".", ","), 1, 0, 'R');
        $pdf->Cell($w[3], 6, $producto[3] . "%", 1, 0, 'R');
        $pdf->Cell($w[4], 6, "$ " . number_format($producto[4], 2, ".", ","), 1, 0, 'R');
        $pdf->Ln();
    }

    // Resumen de la factura
    $yposdinamic = 60 + (count($productos) * 10);
    $pdf->setY($yposdinamic);
    $pdf->setX(135);
    $pdf->Ln();

    // Totales
    $resumen = array(
        array("Base Imponible IVA 0%", $factura['base_imponible_0']),
        array("Base Imponible IVA 12%", $factura['base_imponible_12']),
        array("IVA", $factura['iva']),
        array("Total a Pagar", $factura['total'])
    );

    $w2 = array(40, 40);
    foreach ($resumen as $row) {
        $pdf->setX(115);
        $pdf->Cell($w2[0], 6, $row[0], 1);
        $pdf->Cell($w2[1], 6, "$ " . number_format($row[1], 2, ".", ","), 1, 0, 'R');
        $pdf->Ln();
    }

    // Términos y condiciones
    $yposdinamic += (count($resumen) * 10);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->setY($yposdinamic);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "TERMINOS Y CONDICIONES");
    $pdf->SetFont('Arial', '', 10);
    $pdf->setY($yposdinamic + 10);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "El cliente se compromete a pagar la factura.");
    $pdf->setY($yposdinamic + 20);
    $pdf->setX(10);
    $pdf->Cell(5, $textypos, "Powered by Evilnapsis");

    $pdf->output();
} else {
    echo "ID de factura no proporcionado.";
}
?>
